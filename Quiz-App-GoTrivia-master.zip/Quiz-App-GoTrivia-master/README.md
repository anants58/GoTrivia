# Quiz-App-GoTrivia
A simple android quiz app
## Tools Used:-
Android Studio, Phonegap, Sqlite (database)
## Screenshots
<pre><img src="Screenshots/Home.PNG" width = "200">   <img src="Screenshots/Question_page.PNG" width = "194">   <img src="Screenshots/After_Answering_All.PNG" width = "194">   <img src="Screenshots/Time_Up_Page.PNG" width = "194"></pre><br/>
<pre><img src="Screenshots/Wrong_answer_page.PNG" width = "200"> <img src="Screenshots/Categories.PNG" width = "222"> <img src="Screenshots/Result.PNG" width = "203"> <img src="Screenshots/Score_Fragement.PNG" width = "199"></pre><br/>
<pre><img src="Screenshots/Navigation_1.PNG" width = "190">   <img src="Screenshots/Toast_Message.PNG" width = "208">   <img src="Screenshots/Help_Fragement.PNG" width = "207">   <img src="Screenshots/Developer_Fragement.PNG" width = "186"></pre><br/>
Open and run in android studio.<br/>
Hope this small project may help...! GoodLuck..
